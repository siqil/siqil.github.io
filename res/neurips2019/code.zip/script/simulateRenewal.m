function [ seqs ] = simulateRenewal( n, stop, mu, f, f_upper, f_rbound )
%SIMULATE Summary of this function goes here
%   Detailed explanation goes here
mu_f = @(x) repmat(mu, size(x));
dt = 0.1;
dts = 0:dt:stop;
for i=1:n
    seqs(i).Start = 0;
    seqs(i).Stop = stop;
    seqs(i).dt = dt;
    marks = [];
    times = [];
    intensity = [];
    lambda_sup = mu;
    lambda = mu_f;
    t = 0;
    T = stop;
    t_old = t;
    update = 0;
    while t < stop
        s = exprnd(1/lambda_sup);
        t_new = t + s;
        lambda_old = lambda;
        if t_new > T
            t = T;
            lambda = mu_f;
            lambda_sup = mu;
            T = stop;
            update = 1;
        else
            u = rand;
            t = t_new;
            % accepted
            if u * lambda_sup <= lambda(t_new - t_old)
                times = [times, t];
                marks = [marks, 1];
                T = min([t + f_rbound, stop]);
                lambda = f;
                lambda_sup = f_upper;
                update = 1;
            end
        end
        if update
            intensity = [intensity, lambda_old(dts(dts>t_old & dts<=t)-t_old)];
            t_old = t;
            update = 0;
        end
    end
    seqs(i).Time = times;
    seqs(i).Mark = marks;
    seqs(i).Intensity = intensity;
end

