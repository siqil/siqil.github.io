function [model, loglike_test, loglike_train] = runGPFast(options, Seqs_train, Seqs_test, auto, grid, q, kl, tie)
%runGPFast - train/test (C)GPRPP
%
% Inputs:
%    options - common options
%    Seqs_train - training data
%    Seqs_test - test data
%    auto - 1: automatic active region selection to reduce number of
%    inducing points
%    grid - positions of the inducing points
%    q - number of regression terms
%    kl - 0: CGPRPP; 1: GPRPP
%    tie - 1: tie parameters across q

options.auto_ip = auto;
if auto == 0
    options.grid = grid;
    options.m = length(grid);
else
    options.grid = grid;
    options.m = max(grid);
end
options.kl = kl;
options.Q = q;
options.repeat = 1;
options.detail = 1;
options.figure = 0;
options.remove = 1;
options.tol = 1e-3;
options.tie = tie;

if isfield(options, 'target')
    fprintf('target = %d\n', options.target);
    switch nargout
        case 0
            runForTarget(options, Seqs_train, Seqs_test);
        case 1
            model = runForTarget(options, Seqs_train, Seqs_test);
        case 2
            [model, loglike_test] = runForTarget(options, Seqs_train, Seqs_test);
        case 3
            [model, loglike_test, loglike_train] = runForTarget(options, Seqs_train, Seqs_test);
    end
else
    model = cell(1,options.U);
    loglike_train = NaN(options.U, 2);
    loglike_test = NaN(options.U, 2);
    k = nargout;
    for target=1:options.U
        cur_options = options;
        cur_options.target = target;
        fprintf('target = %d\n', target);
        switch k
            case 0
                runForTarget(cur_options, Seqs_train, Seqs_test);
            case 1
                model{target} = runForTarget(cur_options, Seqs_train, Seqs_test);
            case 2
                [model{target}, loglike_test(target, :)] = runForTarget(cur_options, Seqs_train, Seqs_test);
            case 3
                [model{target}, loglike_test(target, :), loglike_train(target, :)] = runForTarget(cur_options, Seqs_train, Seqs_test);
        end
    end
end
end

function [model, loglike_test, loglike_train] = runForTarget(options, Seqs_train, Seqs_test)
suffix = ['_',num2str(options.Q)];
if options.kl == 0
    suffix=[suffix,'_kl'];
elseif options.kl == 2
    suffix=[suffix,'_kl_part'];
end
if options.tie == 1
    suffix=[suffix,'_tie'];
end
if options.auto_ip == 1
    suffix=[suffix,'_auto'];
elseif options.auto_ip == 2
    suffix=[suffix,'_auto_2'];
end
filename = [options.dataSource,'_GPFast',suffix];
%% train
options.model_file = ['model_',filename,'_',num2str(options.target),'.mat'];
if options.train == 1
    data.train = preprocessGPFast(Seqs_train, options);
    data.test = preprocessGPFast(Seqs_test, options);
    model = trainGPFast(data,options);
else
    model = trainGPFast([], options);
end
if ~isempty(model)
    model.filename = filename;
end
%% likelihood
if nargout >= 2
    if isempty(model)
        loglike_test=NaN;
    else
        data.test = preprocessGPFast(Seqs_test, options);
        loglike_test = calLikelihoodGPFast(data.test, model);
        fprintf('test: %.4g\n', loglike_test);
    end
end
if nargout >= 3
    if isempty(model)
        loglike_train=NaN;
    else
        data.train = preprocessGPFast(Seqs_train, options);
        loglike_train = calLikelihoodGPFast(data.train, model);
        fprintf('train: %.4g\n', loglike_train);
    end
end
end


