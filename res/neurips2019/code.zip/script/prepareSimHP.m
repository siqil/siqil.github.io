%% setup
clear;close all;clc;
T = 20;
A = 0.1;
mu = 0.1;
f = @(x) A*exp(-(x-10).^2/4);
dt = 0.1;
x = 0:dt:T;
%%
fig=figure(1);
x0=0;
y0=0;
width=200;
height=200;
set(fig,'position',[x0,y0,width,height])
plot(x, mu+f(x))
hold on
plot(xlim, [mu, mu], '--')
hold off
ylim([mu-1e-2, A+mu])
xlabel('Time elapsed')
ylabel('Influence')
% savefigure('simulation_HP_gauss_true_influence.pdf');
%%
rng(1)
Seqs = simulateHP(200, 100, mu, f, T);
%%
save('simulation_HP_gauss.mat', 'Seqs')