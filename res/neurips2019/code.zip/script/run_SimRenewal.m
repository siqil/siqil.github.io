%% setup
clear;close all;clc;
%%
runners = {
    @(o, train, test) runHP_LS(o, train, test, 1, 20),...
    @(o, train, test) runHP(o, train, test, 'gauss', 10.^(-2:4), 10.^(-2:4), 0, 5/pi, 5*(0:4-1)),...
    @(o, train, test) runGPFast(o, train, test, 0, 5*(0:4-1), 1, 0, 0),...
    @(o, train, test) runGPFast(o, train, test, 0, 5*(0:4-1), 1, 1, 0)
    };
options.dataSource = 'simulation_renewal';
rawData = load([options.dataSource, '.mat']);
U = zeros(length(rawData.Seqs),1);
for i = 1:length(rawData.Seqs)
    U(i) = max(rawData.Seqs(i).Mark);
end
U = max(U);
options.U = U;
disp(U);
%% train
[Seqs_train, Seqs_test] = splitTrainTest(rawData.Seqs);
options.forceTrain = 1;
options.train = 1;
options.test = 0;
cur_options = options;
cur_options.target=1;
for j=1:length(runners)
    runner = runners{j};
    runner(cur_options, Seqs_train, Seqs_test);
end