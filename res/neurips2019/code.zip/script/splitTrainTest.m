function [ Seqs_train, Seqs_test ] = splitTrainTest( Seqs )
%SPLITTRAINTEST Summary of this function goes here
%   Detailed explanation goes here
n_train = ceil(length(Seqs) / 2);
n_test = length(Seqs)-n_train;
Seqs_train = Seqs(1:n_train);
Seqs_test = Seqs(n_train+(1:n_test));

end

