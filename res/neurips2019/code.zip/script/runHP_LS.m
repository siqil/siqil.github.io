function [model] = runHP_LS( options, Seqs_train, Seqs_test, h, k )

options.h = h;
options.k = k;
filename = [options.dataSource,'_HP_LS'];
options.model_file = ['model_',filename,'_',num2str(h),'_',num2str(k),'.mat'];
%%
[model] = trainHP_LS(Seqs_train, options);
if ~isempty(model)
    model.filename = filename;
end
end