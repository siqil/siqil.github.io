function [model, loglike_test, loglike_train] = runHP(options, Seqs_train, Seqs_test, kernel,...
    alphaGS, alphaS, alphaLR, bandwidth, landmark)
%%
options.kernel = kernel;
options.alphaGS = alphaGS;
options.alphaS = alphaS;
options.alphaLR = alphaLR;
if nargin >= 8
    options.bandwidth = bandwidth;
    options.landmark = landmark;
end
%%
suffix = '';
if any(options.alphaS ~= 0) || ...
        any(options.alphaGS ~= 0) || ...
        any(options.alphaLR ~= 0)
    suffix = [suffix, '_sparse'];
end
if isfield(options, 'landmark')
    suffix = [suffix, '_landmark'];
end
filename = [options.dataSource,'_HP_',options.kernel,suffix];
options.model_file = ['model_',filename,'.mat'];
[model, alg] = trainHP(Seqs_train, options);
model.filename = filename;
%%
if nargout >= 2
    loglike_test = Loglike_Basis_Single(Seqs_test, model, alg);
end
if nargout >= 3
    loglike_train = Loglike_Basis_Single(Seqs_train, model, alg);
end
end

