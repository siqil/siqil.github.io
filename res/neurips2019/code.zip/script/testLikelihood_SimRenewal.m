%% setup
clear;close all;clc;
%%
modelDataSource = 'simulation_renewal';
testDataSource = 'simulation_renewal';
U = 1;
rawData = load([testDataSource,'.mat']);
[Seqs_train, Seqs_test] = splitTrainTest(rawData.Seqs);
%%
options.U = U;
options.dataSource = modelDataSource;
options.train = 0;
options.test = 0;
options.forceTrain = 0;
options.target = 1;
i = 1;
Q = 1;
tie = 0;
%%
for kl=0:1
    [model, loglike_test, loglike_train] = ...
        runGPFast(options, Seqs_train, Seqs_test, 0, 0, Q, kl, tie);
    if ~isempty(model)
        for u=1:U
            loglike(i).target = u;
            loglike(i).method = 'GPRPP';
            loglike(i).Q = Q;
            loglike(i).tie = tie;
            loglike(i).KL = kl;
            loglike(i).train_pos = loglike_train(u, 1);
            loglike(i).train_neg = loglike_train(u, 2);
            loglike(i).train = sum(loglike_train(u, :), 2);
            loglike(i).test_pos = loglike_test(u, 1);
            loglike(i).test_neg = loglike_test(u, 2);
            loglike(i).test = sum(loglike_test(u, :), 2);
            i = i+1;
        end
    end
end
%%
[model1, loglike_test1, loglike_train1] = ...
    runHP(options, Seqs_train, Seqs_test, 'gauss', 10.^(-2:4), 10.^(-2:4), 0, 5/pi, 5*(0:4-1));
for u=1:U
    loglike(i).method = 'HP-GS';
    loglike(i).target = u;
    loglike(i).train_pos = loglike_train1(u, 1);
    loglike(i).train_neg = loglike_train1(u, 2);
    loglike(i).train = sum(loglike_train1(u, :), 2);
    loglike(i).test_pos = loglike_test1(u, 1);
    loglike(i).test_neg = loglike_test1(u, 2);
    loglike(i).test = sum(loglike_test1(u, :), 2);
    i = i+1;
end
%%
[model2] = runHP_LS(options,Seqs_train,Seqs_test, 1, 20);
loglike_train = Loglike_LS_Single(Seqs_train, model2);
loglike_test = Loglike_LS_Single(Seqs_test, model2);
for u=1:U
    loglike(i).method = 'HP-LS';
    loglike(i).target = u;
    loglike(i).train_pos = loglike_train(u, 1);
    loglike(i).train_neg = loglike_train(u, 2);
    loglike(i).train = sum(loglike_train(u, :), 2);
    loglike(i).test_pos = loglike_test(u, 1);
    loglike(i).test_neg = loglike_test(u, 2);
    loglike(i).test = sum(loglike_test(u, :), 2);
    i = i+1;
end
%%
writetable(struct2table(loglike), ['loglike_',testDataSource,'.csv']);