%% setup
clear;close all;clc;
%%
testDataSource = 'simulation_HP_gauss';
df = readtable(['loglike_',testDataSource,'.csv']);
%%
fig = figure;
tie=1;
i = 1;
labels = cell(1,1);
x0=0;
y0=0;
width=200;
height=200;
set(fig,'position',[x0,y0,width,height])
hold all
for kl=0:1
    cur = df(df.KL==kl & df.tie==tie,:);
    x = cur.Q;
    y = cur.test;
    if kl==1
        label=cur.method(1);
        mark='-x';
    else
        label=strcat('C',cur.method(1));
        mark='-*';
    end
    plot(x, y,mark)
    labels(i) = label;
    i = i+1;
end
hold off
xlabel('Q');
ylabel('log-likelihood');
leg = legend(labels);
set(leg,'Location','northoutside')
%%
% savefigure(['vary_Q.pdf']);