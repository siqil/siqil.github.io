%% setup
clear;close all;clc;
%%
dataSource = 'simulation_renewal';
modelDataSource = dataSource;
options.U = 1;
options.target = 1;
options.dataSource = modelDataSource;
options.test = 0;
options.train = 0;
options.forceTrain = 0;
rawData = load([dataSource, '.mat']);
[Seqs_train, Seqs_test] = splitTrainTest(rawData.Seqs);
calInfluenceHPThis = @(m, N, dt) calInfluenceHP(m, N, dt, options.target);
i = 1;
Q = 1;
tie = 0;
kl = 0;
factor = 1.2;
%%
model{i} = runGPFast(options, Seqs_train, Seqs_test, 0, 1, Q, kl, tie);
if ~isempty(model{i})
    plotInfluence(model{i}, @calInfluenceGPFast, ceil(factor*200), 0.1);
    %         savefigure([model{i}.filename,'_influence.pdf']);
    i = i + 1;
end
%%
[model{i}] = runHP(options, Seqs_train, Seqs_test, 'gauss', 1, 1, 1, 1, 1);
plotInfluence(model{i}, calInfluenceHPThis,  ceil(factor*200), 0.1);
% savefigure([model{i}.filename,'_influence.pdf']);
i = i + 1;
%%
[model{i}] = runHP_LS(options, Seqs_train, Seqs_test, 1, 20);
plotInfluence(model{i}, @(m, N, dt) calInfluenceHP_LS(m, N, dt, options.target), ceil(factor*model{i}.k), model{i}.h);
% savefigure([model{i}.filename,'_influence.pdf']);
i = i + 1;