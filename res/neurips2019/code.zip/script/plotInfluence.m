function [fig, Phi, Mu] = plotInfluence( model, calInfluence, N, dt, U)
%PLOTINFLUENCE Summary of this function goes here
%   Detailed explanation goes here
fig = figure;
[Phi, Mu] = calInfluence(model, N, dt);
if nargin < 5
    U = size(Phi, 1);
end
n_col = 5;
n_row = ceil(U / n_col);
x0=0;
y0=0;
width=200*n_col;
height=200*n_row;
set(fig,'position',[x0,y0,width,height])
for v = 1:U;
    subplot(n_row, n_col, v)
    hold on
    plot(dt*(0:(size(Phi,2)-1)), Phi(v,:), '-')
    plot(dt*(0:(size(Mu,2)-1)), Mu, '--')
    hold off
    axis tight
    yl = ylim;
    yd = yl(2) - yl(1);
    yl(1) = yl(2) - yd*1.05;
    ylim(yl)
    xlabel('Time elapsed')
    if U > 1
        ylabel(['Influence ', sprintf('%d', v)])
    else
        ylabel('Influence');
    end
end
end

