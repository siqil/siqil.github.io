%% setup
clear;close all;clc;
T = 20;
A = 0.1;
f = @(x) A-A*sin(x*2*pi/T);
dt = 0.1;
x = 0:dt:T;
%%
fig=figure(1);
x0=0;
y0=0;
width=200;
height=200;
set(fig,'position',[x0,y0,width,height])
plot(x, f(x))
hold on
plot(xlim, [A, A], '--')
hold off
xlabel('Time elapsed')
ylabel('Influence')
% savefigure('simulation_renewal_true_influence.pdf');
%%
rng(1)
Seqs = simulateRenewal(200, 100, A, f, 2*A, T);
%%
save('simulation_renewal.mat', 'Seqs')