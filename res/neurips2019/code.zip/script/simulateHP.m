function [ seqs ] = simulateHP( n, stop, mu, f, f_rbound )

dt = 0.1;
dts = 0:dt:stop;
for i=1:n
    seqs(i).Start = 0;
    seqs(i).Stop = stop;
    seqs(i).dt = dt;
    marks = [];
    times = [];
    lambda = repmat(mu, size(dts));
    t = 0;
    T = stop;
    update = 0;
    while t < stop
        lambda_sup = max(lambda(dts > t & dts <= T));
        s = exprnd(1/lambda_sup);
        t_new = t + s;
        if t_new > T
            t = T;
        else
            u = rand;
            t = t_new;
            % accepted
            if u * lambda_sup <= interp1(dts, lambda, t_new)
                times = [times, t];
                marks = [marks, 1];
                update = 1;
            end
        end
        if update
            t_r = min([T, t+f_rbound]);
            idx = dts > t & dts <= t_r;
            lambda(idx) = lambda(idx) + f(dts(idx) - t);
            update = 0;
        end
    end
    seqs(i).Time = times;
    seqs(i).Mark = marks;
    seqs(i).Intensity = lambda;
end

