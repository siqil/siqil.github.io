function Loglike = Loglike_Basis_Single( Seqs, model, alg )

Aest = model.A;
muest = model.mu;

D = size(Aest, 1);

tic;


Loglike = zeros(D, 2);

for c = 1:length(Seqs)
    Time = Seqs(c).Time;
    Event = Seqs(c).Mark;
    Tstart = Seqs(c).Start;
    
    if isempty(alg.Tmax)
        Tstop = Seqs(c).Stop;
    else
        Tstop = alg.Tmax;
        indt = Time < alg.Tmax;
        Time = Time(indt);
        Event = Event(indt);
    end
        
    dT = Tstop - Time;
    GK = Kernel_Integration(dT, model);
    
    Nc = length(Time);
    
    i = 1;
    while i <= Nc
        i2 = i + 1;
        while i2 <= Nc && Time(i2) == Time(i)
            i2 = i2 + 1;
        end
        i2 = i2 - 1;
        for ui=Event(i:i2)
            
            ti = Time(i);
            
            lambdai = muest(ui);

            if i>1
                
                tj = Time(1:i-1);
                uj = Event(1:i-1);
                
                dt = ti - tj;
                gij = Kernel(dt, model);
                auiuj = Aest(uj, :, ui);
                pij = auiuj .* gij;
                lambdai = lambdai + sum(pij(:));
            end
            
            Loglike(ui, 1) = Loglike(ui, 1) - log(lambdai);
            
        end
        i = i2 + 1;
    end
    Loglike(:, 2) = Loglike(:, 2) + (Tstop-Tstart)*muest;
    
    Loglike(:, 2) = Loglike(:, 2) + squeeze(sum(sum(repmat(GK, 1, 1, D).*Aest(Event,:,:), 1), 2));
    
end

Loglike = -Loglike;
end





