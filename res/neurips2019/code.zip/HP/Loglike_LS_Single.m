function [ Loglike ] = Loglike_LS_Single( Seqs, model )

Aest = model.A;
muest = model.mu;
D = size(Aest, 1);
h = model.h;
k = model.k;
Loglike = zeros(D, 2);
eps = 1e-8;

for c = 1:length(Seqs)
    Time = Seqs(c).Time;
    Event = Seqs(c).Mark;
    Tstart = Seqs(c).Start;
    
    if isempty(model.Tmax)
        Tstop = Seqs(c).Stop;
    else
        Tstop = model.Tmax;
        indt = Time < model.Tmax;
        Time = Time(indt);
        Event = Event(indt);
    end
    
    N = ceil((Tstop - Tstart)/h);
    if N == 0
        N = 1;
    end
    lambda = repmat(muest, 1, N);    
    Nc = length(Time);
    
    i = 1;
    while i <= Nc
        i2 = i;
        while i2 <= Nc && Time(i2) == Time(i)
            i2 = i2 + 1;
        end
        i2 = i2 - 1;
        for ui=Event(i:i2)
            ti = Time(i) - Tstart;
            idx = ceil(ti / h);
            idx(idx <= 0) = 1;
            l = idx+1;
            r = min([idx+k, N]);
            lambda(:, l:r) = lambda(:, l:r) + permute(model.A(ui, 1:r-l+1, :), [3, 2, 1]);
        end
        i = i2 + 1;
    end
    
    lambda(lambda < eps) = eps; 
    Loglike(:, 2) = Loglike(:, 2) - sum(lambda, 2)*model.h;
    dt = Time - Tstart;
    dt = ceil(dt / h);
    dt(dt <= 0) = 1;
    for i=1:Nc
        ui = Event(i);
        Loglike(ui, 1) = Loglike(ui, 1) + log(lambda(ui, dt(i)));
    end
end
end

