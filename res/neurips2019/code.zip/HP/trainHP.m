function [ model, alg ] = trainHP( Seqs_train, options )

train = options.forceTrain;
model_file = options.model_file;

if train == 0
    try
        load(model_file);
    catch
        train = 1;
    end
end

if train == 1
    alg.GroupSparse = 0;
    alg.alphaGS = 0;
    alg.Sparse = 0;
    alg.alphaS = 0;
    alg.LowRank = 0;
    alg.alphaLR = 0;
    alg.outer = 500;
    alg.rho = 0.1;
    alg.inner = 500;
    alg.thres = 1e-3;
    alg.Tmax = [];
    alg.storeErr = 0;
    alg.storeLL = 0;
    if isfield(options, 'target')
        alg.target = options.target;
    end
    [alphaGS, alphaS, alphaLR] = ndgrid(...
        options.alphaGS, options.alphaS, options.alphaLR);
    alphas = horzcat(alphaGS(:), alphaS(:), alphaLR(:));
    algs = cell(size(alphas, 1), 1);
    K = 5;
    models = cell(size(alphas, 1), K);
    likes = zeros(size(alphas, 1), K);
    n = length(Seqs_train);
    n_val = ceil(n / K);
    for i=1:size(alphas, 1)
        algs{i} = alg;
        algs{i}.alphaGS = alphas(i, 1);
        algs{i}.alphaS = alphas(i, 2);
        algs{i}.alphaLR = alphas(i, 3);
        algs{i}.GroupSparse = (algs{i}.alphaGS ~=0);
        algs{i}.Sparse = (algs{i}.alphaS ~= 0);
        algs{i}.LowRank = (algs{i}.alphaLR ~= 0);
    end
    if size(alphas, 1) > 1
        parfor i=1:size(algs, 1)
            for k=1:K
                fprintf('Started %d (%.4g, %.4g, %.4g)\n', ...
                    k, algs{i}.alphaGS, algs{i}.alphaS, algs{i}.alphaLR);
                tstart = tic;
                val_idx = false(n, 1);
                val_idx(1+(k-1)*n_val:min([k*n_val, n])) = true;
                train_set = Seqs_train(~val_idx);
                val_set = Seqs_train(val_idx);
                models{i, k} = Initialization_Basis_My(train_set, options);
                models{i, k} = Learning_MLE_Basis_My(val_set, models{i, k}, algs{i});
                like = Loglike_Basis_Single(val_set, models{i, k}, algs{i});
                if isfield(algs{i}, 'target')
                    likes(i, k) = sum(like(algs{i}.target, :), 2);
                else
                    likes(i, k) = sum(sum(like));
                end
                time_train = toc(tstart);
                fprintf('Finished %d (%.4g, %.4g, %.4g) %.4f s\n', ...
                    k, algs{i}.alphaGS, algs{i}.alphaS, algs{i}.alphaLR, time_train);
            end
        end
        mean_likes = mean(likes, 2);
        [~, i] = max(mean_likes);
        alg = algs{i};
    else
        alg = algs{1};
    end
    tstart = tic;
    model = Initialization_Basis_My(Seqs_train, options);
    model = Learning_MLE_Basis_My(Seqs_train, model, alg);
    time_train = toc(tstart);
    save(model_file, 'model', 'alg', 'options', 'time_train');
    fprintf('Finished training: %.4f s\n', time_train);
end

end

