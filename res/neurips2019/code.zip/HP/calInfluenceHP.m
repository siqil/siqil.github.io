function [ Phi, Mu ] = calInfluenceHP( para, N, dt, u )

Phi = zeros(size(para.A, 1), N);

time_stamp = 0:dt:(N-1)*dt;

Mu = repmat(para.mu(u), size(time_stamp));

for v = 1:size(para.A, 1)
    
    basis = Kernel(time_stamp(:), para);
    Phi(v,:) = Mu + para.A(v,:,u)*basis';
    
end

end

