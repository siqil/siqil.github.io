function [ model, options ] = trainHP_LS( Seqs, options )

train = options.forceTrain;
model_file = options.model_file;
if train == 0
    try
        load(model_file);
    catch
        train = 1;
    end
end

if train == 1
    model.D = options.U;
    model.h = options.h;
    model.k = options.k;
    model = Initialization_Discrete(Seqs, model.h, model.k);
    model = Learning_LS_Discrete_My( Seqs, model );
    save(model_file, 'model', 'options');
end
end

