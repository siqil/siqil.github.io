function [ Phi, Mu ] = calInfluenceHP_LS( para, N, dt, u )

time_stamp = 0:dt:(N-1)*dt;
Mu = repmat(para.mu(u), 1, N);
Phi = repmat(para.mu(u), size(para.A, 1), N);

for v = 1:size(para.A, 1)
    idx = ceil(time_stamp/para.h)';
    idx(idx <= 0) = 1;
    idx = idx(idx < para.k);
    idx_dt = 1:length(idx);
    Phi(v,idx_dt) = Phi(v,idx_dt) + para.A(v,idx,u);
end
eps = 1e-8;
Phi(Phi<eps)=eps;
end

