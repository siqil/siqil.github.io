function g = Kernel(dt, para)
distance = repmat(dt(:), [1, length(para.landmark(:))]) - ...
            repmat(para.landmark(:)', [length(dt), 1]);

switch para.kernel
    case 'exp'
        g = exp(-para.w * distance);
        g(g>1) = 0;
        g = para.w * g;
        
    case 'gauss'
        g = exp(-(distance.^2)./(2*para.w^2))./(sqrt(2*pi)*para.w);
        
    otherwise
        disp('Error: please assign a kernel function!');
end
    
