function model = Initialization_Basis_My(Seqs, options)

D = zeros(length(Seqs),1);
for i = 1:length(Seqs)
    D(i) = max(Seqs(i).Mark);
end
D = max(D);

n_sample = length(Seqs);

if isfield(options, 'landmark');
    model.kernel = options.kernel;
    model.w = options.bandwidth;
    model.landmark = options.landmark;
else
    sigma = zeros(D);
    Tmax = zeros(D);
    est = cell(D);
    id = randperm(length(Seqs));
    for n = 1:min([length(id), n_sample])
        for i = 2:length(Seqs(id(n)).Time)
            ti = Seqs(id(n)).Time(i);
            di = Seqs(id(n)).Mark(i);
            for j = 1:i-1
                tj = Seqs(id(n)).Time(j);
                if tj < ti
                    dj = Seqs(id(n)).Mark(j);
                    est{di, dj} = [est{di, dj}, ti - tj];
                end
            end
        end
    end
    
    for di = 1:D
        for dj = 1:D
            sigma(di, dj) = ((4*std(est{di, dj})^5)/(3*length(est{di, dj})))^0.2;
            Tmax(di, dj) = mean(est{di, dj});
        end
    end
    
    if isfield(options, 'target')
        Tmax = min(Tmax(options.target, :))/2;
    else
        Tmax = min(Tmax(:))/2;
    end
    
    model.kernel = options.kernel;
    
    if isfield(options, 'bandwidth')
        model.w = options.bandwidth;
    elseif isfield(options, 'target')
        model.w = min(sigma(options.target, :))/2;
    else
        model.w = min(sigma(:))/2;
    end
    
    switch model.kernel
        case 'exp'
            model.landmark = 0;
        otherwise
            model.landmark = model.w*(0:ceil(Tmax/model.w));
    end
end

model.A = rand(D, length(model.landmark), D)./(D^2 * length(model.landmark));
model.mu = rand(D, 1)./D;

