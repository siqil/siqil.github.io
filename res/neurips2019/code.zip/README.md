# GPRPP

This is the code for the paper: "Nonparametric Regressive Point Processes Based on Conditional Gaussian Processes", NeurIPS 2019.

## Dependencies

The code depends on
- [GPML Toolbox version 3.4](http://gaussianprocess.org/gpml/code/matlab/release/oldcode.html)
- [minConf](https://www.cs.ubc.ca/~schmidtm/Software/minConf.html)
- [FACTORIZE](https://www.mathworks.com/matlabcentral/fileexchange/24119-don-t-let-that-inv-go-past-your-eyes-to-solve-that-system-factorize)
- [THAP](https://github.com/HongtengXu/Hawkes-Process-Toolkit)

The code has been tested on MATLAB R2015a.

## Structure

- `script/` contains the main scripts for the experiments.
- `GPfast/` contains the implementation of GPRPP.
- `HP/` contains the code for the baselines, which are mostly adapted from THAP.

## Experiments

Before running any experiment, you need to download all the dependencies and add them to MATLAB search path, together with the above folders.

### Synthetic data

- To generate data, run `prepareSimRenewal.m` or `prepareSimHP.m`.
- To train the models, run `run_SimRenewal.m` or `run_SimHP.m`. 
- To calculate the test log-likelihood, run `testLikelihood_SimRenewal.m` or `testLikelihood_SimHP.m`.
- To plot the influence functions, run `testInfluence_SimRenewal.m` or `testInfluence_SimHP.m`.

Additionally, to plot the log-likelihood against Q, run `plotVaryQ.m`.

## Acknowledgement

The implementation of GPRPP (in `GPfast/`) is partially based on the code of [BaNPPA](https://github.com/Dinghy/BaNPPA).
