function [ feature ] = genFeat( data, target, timeInf, U, Q)
idx = ones(U, 1);
D = sum(Q);
lastTime = cell(1, U);
for u=1:U
    lastTime{u} = repmat(-timeInf, 1, Q(u));
end
feature = cell(1, U);
feature{target} = zeros(length(data{target}.time), D);
while 1
    minTime = inf;
    minU = [];
    % find next smallest time
    for u=1:U
        if idx(u) <= length(data{u}.time)
            uTime = data{u}.time(idx(u));
            if minTime > uTime
                minTime = uTime;
                minU = [u];
            elseif minTime == uTime
                minU = [minU, u];
            end
        end
    end
    if isempty(minU)
        break
    end
    if any(minU == target)
        feature{target}(idx(target), :) = bsxfun(@minus, minTime, [lastTime{:}]);
    end
    for u=minU
        lastTime{u}(2:Q(u)) = lastTime{u}(1:Q(u)-1);
        lastTime{u}(1) = minTime;
    end
    idx(minU) = idx(minU) + 1;
end
end

