function [vPsi,DvPsiDx] = vectorPsiGPFast(model, dataset, vAlpha_sqrt, vGamma)

D = model.D;
M = model.M_sum;
vPsi = zeros(M, 1);

if nargout==2
    DvPsiDx = cell(1, D);
end
sqrt2 = sqrt(2);

for d=1:D
    DvPsiDx{d} = cell(1, 2);
    for k=1:2
        DvPsiDx{d}{k} = zeros(size(vPsi));
    end
    if isempty(model.Xm{d})
        continue
    end
    nAlphaSqrt = vAlpha_sqrt(d);
    nGamma = vGamma(d);
    nSqrt2Alpha = (sqrt2*nAlphaSqrt);
    mask_d = model.Xm_mask{d};
    vZ_d = model.Xm{d};
    vZ_d = vZ_d / nSqrt2Alpha;
    if ~isempty(dataset.pair_tdiff_diff{d,d})
        N_d = length(dataset.pair_tdiff_diff{d,d});
        vZMax = bsxfun(@minus,...
            repmat(vZ_d, 1, N_d),...
            dataset.pair_tdiff_max{d,d}(:,1)'/nSqrt2Alpha);
        vZMin = bsxfun(@minus,...
            repmat(vZ_d, 1, N_d),...
            dataset.pair_tdiff_min{d,d}(:,1)'/nSqrt2Alpha);
        vPsi_save = -sqrt(pi)*nAlphaSqrt/sqrt2*...
            (sum(erf(vZMax), 2) - sum(erf(vZMin), 2));
        vPsi(mask_d) = vPsi(mask_d) + nGamma * vPsi_save;
        if nargout==2
            mTmp_a = 1;
            % - sqrt(pi) / 2 is canceled out
            mTmp_b = nSqrt2Alpha*...
                (sum(vZMax.*exp(-(vZMax).^2), 2) -...
                sum(vZMin.*exp(-(vZMin).^2), 2));
            DvPsiDx{d}{1}(mask_d) = DvPsiDx{d}{1}(mask_d) + ...
                nGamma * (vPsi_save .* mTmp_a + mTmp_b);
            DvPsiDx{d}{2}(mask_d) = DvPsiDx{d}{2}(mask_d) + ...
                2 * nGamma * vPsi_save;
        end
    end
end
end

