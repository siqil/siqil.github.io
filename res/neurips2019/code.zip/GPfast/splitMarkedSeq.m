function [ split ] = splitMarkedSeq( time, mark, dim )

split = cell(1, dim);

for i=1:length(time)
    split{mark(i)} = [split{mark(i)}; time(i)];
end

end

