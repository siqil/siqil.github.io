function modelD = calPointValueGPFast(model, data, modelD, u, bflag)

switch bflag
    case 0
        modelD = calPreMeanVarGPFast(model, data.feature{u}, modelD);
    case 2
        modelD = calPreMeanVarGPFast(model, data.feature{u}, modelD);
        for d=1:model.D
            x_d = data.feature{u}(:, d);
            mask = isfinite(x_d);
            for k=1:2
                modelD.DknmDx{d}{k} = feval(model.cov{:}, ...
                    model.GP.logtheta{d}, x_d(mask), model.Xm{d}, k);
            end
            modelD.DdiagKnnDx{d}{2} = feval(model.cov{:}, ...
                model.GP.logtheta{d}, x_d(mask), 'diag', 2);
        end
end
[vMean, vVar, vMean2DVar, ~, mDGG, log_lambda] = ...
    calPointMeanVarGPFast(model, modelD);
modelD.f = modelD.f + sum(log_lambda);

switch bflag
    case 1
        mDMutmp = mDGG;
        % times 2 b/c L appears twice in LL^T
        mDLtmp = 2*(-mDGG.*vMean2DVar+1)./vVar;
        vLtmp=mDLtmp(:);
        vMutmp=(mDMutmp(:)./vVar(:));
        vMutmp = vMutmp.*vMean(:);
        mMulti=repmat(vLtmp,1,model.M_sum)';
        modelD.var.Mu = modelD.var.Mu+...
            modelD.KnmInvKmm'*vMutmp;
        modelD.var.L = modelD.var.L+...
            (mMulti.*modelD.KnmInvKmm')*modelD.KnmInvKmm;
        % L is multiplied outside after sum over all U
    case 2
        dL_dVar = (-mDGG.*vMean2DVar+1)./vVar;
        dL_dMean2 = vMean.*mDGG./vVar;
        Qnm_Mean2 = modelD.InvKmmMuG * dL_dMean2;
        Qmm_Mean2 = -Qnm_Mean2 * modelD.KnmInvKmm;
        scaled_KnmInvKmm = bsxfun(@times, modelD.KnmInvKmm, dL_dVar');
        I = speye(model.M_sum);
        Qnm_Var = (2*modelD.InvKmmSigma - I) * scaled_KnmInvKmm';
        Qmm_Var = -Qnm_Var * modelD.KnmInvKmm;
        Qnm_Var = Qnm_Var - scaled_KnmInvKmm';
        modelD.prior.g0 = modelD.prior.g0 + ...
            dL_dMean2*(-sum(modelD.KnmInvKmm,2)*model.prior.g);
        modelD.prior.g0 = modelD.prior.g0 + sum(dL_dMean2)*model.prior.g;
        for d=1:model.D
            m_x = modelD.mask{d};
            if ~isempty(model.Xm{d})
                m_d = model.Xm_mask{d};
                modelD.dL_dKmm{d} = modelD.dL_dKmm{d} + Qmm_Mean2(m_d,m_d) + Qmm_Var(m_d,m_d);
                modelD.dL_dKnm{d, u} = Qnm_Mean2(m_d,m_x) + Qnm_Var(m_d,m_x);
            end
            modelD.GP.logtheta{d}(2) = modelD.GP.logtheta{d}(2) + ...
                dL_dVar(m_x)*modelD.DdiagKnnDx{d}{2};
        end
        modelD.GP.logtheta{model.D+1} = modelD.GP.logtheta{model.D+1} + ...
            sum(dL_dVar)*2*modelD.noise;
end
end