function [mPsi,DmPsiDx] = matrixPsiGPFast(model, dataset, vAlpha_sqrt, vAlpha, vGamma)

D = model.D;
M = model.M_sum;
mPsi = zeros(M);
if nargout==2
    DmPsiDx = cell(1,D);
    for d=1:D
        DmPsiDx{d} = cell(1, 2);
        [DmPsiDx{d}{:}] = deal(zeros(M));
    end
end
for j=1:D
    if isempty(model.Xm{j})
        continue
    end
    sqrtalpha_j = vAlpha_sqrt(j);
    alpha_j = vAlpha(j);
    gamma_j = vGamma(j);
    vzj = model.Xm{j};
    mask_zj = model.Xm_mask{j};
    for k=j:D
        if isempty(model.Xm{k})
            continue
        end
        sqrtalpha_k = vAlpha_sqrt(k);
        alpha_k = vAlpha(k);
        gamma_k = vGamma(k);
        vzk = model.Xm{k};
        mask_zk = model.Xm_mask{k};
        denom1 = sqrt(2*(alpha_j+alpha_k));
        denom2 = denom1*sqrtalpha_j*sqrtalpha_k;
        N_j = size(vzj, 1);
        N_k = size(vzk, 1);
        z_diff = bsxfun(@minus, vzj,  vzk') / denom1;
        if ~isempty(dataset.pair_tdiff_diff{j,k})
            tdiff = dataset.pair_tdiff_diff{j,k}/denom1;
            N_l = length(tdiff);
            tmin_z_j = reshape(...
                alpha_k/denom2 * bsxfun(@minus, dataset.pair_tdiff_min{j,k}(:, 1), vzj')',...
                N_j, 1, N_l);
            tmax_z_j = reshape(...
                alpha_k/denom2 * bsxfun(@minus, dataset.pair_tdiff_max{j,k}(:, 1), vzj')',...
                N_j, 1, N_l);
            tmin_z_k = reshape(...
                alpha_j/denom2 * bsxfun(@minus, dataset.pair_tdiff_min{j,k}(:, 2), vzk')',...
                1, N_k, N_l);
            tmax_z_k = reshape(...
                alpha_j/denom2 * bsxfun(@minus, dataset.pair_tdiff_max{j,k}(:, 2), vzk')',...
                1, N_k, N_l);
            tdiff_z = bsxfun(@plus, z_diff, reshape(tdiff, 1, 1, []));
            tmin_z = bsxfun(@plus, tmin_z_j, tmin_z_k);
            tmax_z = bsxfun(@plus, tmax_z_j, tmax_z_k);
            mPsi_jk_1 = (gamma_j*gamma_k*sqrt(pi)*sqrtalpha_j*sqrtalpha_k/denom1)*...
                exp(-tdiff_z.^2);
            mPsi_jk = mPsi_jk_1 .* (erf(tmax_z) - erf(tmin_z));
            mPsi_jk_sum = sum(mPsi_jk, 3);
            mPsi(mask_zj, mask_zk) = mPsi(mask_zj, mask_zk) + mPsi_jk_sum;
            if nargout==2
                dAlpha1j = mPsi_jk_sum;
                dAlpha1k = mPsi_jk_sum;
                w_j = (alpha_j)/(alpha_j+alpha_k);
                w_k = 1 - w_j;
                dAlpha2j = -w_j*mPsi_jk_sum;
                dAlpha2k = -w_k*mPsi_jk_sum;
                dAlpha3 = sum(mPsi_jk .* tdiff_z.^2, 3);
                dAlpha3j = dAlpha3 * 2 * w_j;
                dAlpha3k = dAlpha3 * 2 * w_k;
                dAlpha4 = mPsi_jk_1 .* (2/sqrt(pi)*exp(-tmax_z.^2));
                dAlpha4j = dAlpha4 .* bsxfun(@minus,...
                    2*tmax_z_k, tmax_z * (1 + w_j));
                dAlpha4k = dAlpha4 .* bsxfun(@minus,...
                    2*tmax_z_j, tmax_z * (1 + w_k));
                dAlpha5 = mPsi_jk_1 .* (-2/sqrt(pi)*exp(-tmin_z.^2));
                dAlpha5j = dAlpha5 .* bsxfun(@minus,...
                    2*tmin_z_k, tmin_z * (1 + w_j));
                dAlpha5k = dAlpha5 .* bsxfun(@minus,...
                    2*tmin_z_j, tmin_z * (1 + w_k));
                dAlpha_j = dAlpha1j + dAlpha2j + dAlpha3j + ...
                    sum(dAlpha4j, 3) + sum(dAlpha5j, 3);
                dAlpha_k = dAlpha1k + dAlpha2k + dAlpha3k + ...
                    sum(dAlpha4k, 3) + sum(dAlpha5k, 3);
                DmPsiDx{j}{1}(mask_zj, mask_zk) = DmPsiDx{j}{1}(mask_zj, mask_zk) + ...
                    dAlpha_j;
                DmPsiDx{k}{1}(mask_zj, mask_zk) = DmPsiDx{k}{1}(mask_zj, mask_zk) + ...
                    dAlpha_k;
                
                dGamma = 2 * mPsi_jk_sum;
                DmPsiDx{j}{2}(mask_zj, mask_zk) = DmPsiDx{j}{2}(mask_zj, mask_zk) + ...
                    dGamma;
                DmPsiDx{k}{2}(mask_zj, mask_zk) = DmPsiDx{k}{2}(mask_zj, mask_zk) + ...
                    dGamma;
            end
        end
    end
end

for j=1:D
    if isempty(model.Xm{j})
        continue
    end
    mask_zj = model.Xm_mask{j};
    for k=j+1:D
        if isempty(model.Xm{k})
            continue
        end
        mask_zk = model.Xm_mask{k};
        mPsi(mask_zk, mask_zj) = mPsi(mask_zj, mask_zk)';
        if nargout==2
            DmPsiDx{j}{1}(mask_zk, mask_zj) = DmPsiDx{j}{1}(mask_zj, mask_zk)';
            DmPsiDx{k}{1}(mask_zk, mask_zj) = DmPsiDx{k}{1}(mask_zj, mask_zk)';
            DmPsiDx{j}{2}(mask_zk, mask_zj) = DmPsiDx{j}{2}(mask_zj, mask_zk)';
            DmPsiDx{k}{2}(mask_zk, mask_zj) = DmPsiDx{k}{2}(mask_zj, mask_zk)';
        end
    end
end
end

