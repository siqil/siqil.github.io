function [f] = calLikelihoodGPFast(data, model)

modelD = calKmmKnnGPFast(model, []);
modelD = calKmmVarGPFast(model, modelD);
modelD = calKmmPsiGPFast(model, data, modelD);
vfInt = calIntegralValueGPFast(model, data, modelD);
modelD = calPreMeanVarGPFast(model, data.feature{model.target}, modelD);
[vMean, vVar] = ...
    calPointMeanVarGPFast(model, modelD);
f = zeros(1, 2);
f(1) = sum(log(vMean.^2+vVar));
f(2) = -vfInt;
end