function model = returnVarParamsGPFast(model,V)

nStart = 1;
M = model.M_sum;
M2= M*(M+1)/2;
if model.tie == 1
    for u=1:model.U
        d = sum(model.Q(1:u-1)) + 1;
        M_d = model.M{d};
        Mu = V(nStart:nStart+M_d-1);
        nStart = nStart+M_d;
        for q=1:model.Q(u)
            model.var.Mu(d:d+M_d-1) = Mu;
            d = d + M_d;
        end
    end
else
    model.var.Mu = V(nStart:nStart+M-1);
    nStart = nStart+M;
end
mtmp = tril(ones(M));
mtmp(mtmp==1) = V(nStart:nStart+M2-1);
model.var.L = mtmp;
model.var.Sigma = mtmp*mtmp';
end

