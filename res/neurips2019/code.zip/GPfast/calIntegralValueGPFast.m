function [ fInt, VPsiInvKmmMuG ] = calIntegralValueGPFast( model, data, modelD )

vGamma = zeros(model.D+1, 1);
vGamma(1:model.D) = modelD.Knn;
vGamma(model.D+1) = modelD.noise; % noise
VPsiInvKmmMuG = modelD.invKmmVPsi'*(model.var.Mu-model.prior.g);
fInt = vGamma'*data.T + data.T(end)*model.prior.g^2 - trace(modelD.invKmmMPsi) + ...
     + trace(modelD.invKmmMPsi*modelD.InvKmmSigmaMuG) + 2*model.prior.g*VPsiInvKmmMuG;
end

