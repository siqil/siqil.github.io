function W = extractHyperParamsGPFast(model, deriv)
W=[model.prior.g0];
if model.tie == 1
    for u=1:model.U
        a = sum(model.Q(1:u-1)) + 1;
        W1 = [];
        for d=a:a+model.Q(u)-1
            W1 = [W1,model.GP.logtheta{d}];
        end
        if deriv
            W = [W; sum(W1, 2)];
        else
            W = [W; mean(W1, 2)];
        end
    end
    W = [W;model.GP.logtheta{model.D+1}];
else
    for d=1:model.D+1
        W = [W;model.GP.logtheta{d}];
    end
end
end