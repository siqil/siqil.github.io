function [ modelD ] = calKmmVarGPFast( model, modelD )

M = model.M_sum;
modelD.InvKmmMuG = zeros(M, 1);
modelD.InvKmmSigma = zeros(M);
modelD.InvKmmSigmaMuG = zeros(M);
modelD.InvKmmL = zeros(M);

for j=1:model.D
    if ~isempty(model.Xm{j})
        m_j = model.Xm_mask{j};
        modelD.InvKmmMuG(m_j) = modelD.invKmm{j} * (model.var.Mu(m_j)-model.prior.g);
        modelD.InvKmmSigma(m_j,:) = modelD.invKmm{j} * model.var.Sigma(m_j,:);
        modelD.InvKmmSigmaMuG(m_j,:) = modelD.InvKmmSigma(m_j,:) + ...
            modelD.InvKmmMuG(m_j) * (model.var.Mu-model.prior.g)';
        modelD.InvKmmL(m_j,:) = modelD.invKmm{j} * model.var.L(m_j,:);
    end
end
end

