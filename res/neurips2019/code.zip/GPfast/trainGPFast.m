function [model] = trainGPFast(data,options)

train = options.train;
model_file = options.model_file;

if ~options.forceTrain
    try
        load(model_file, 'model');
        train = 0;
    catch
        fprintf('%s not found\n', model_file);
        model = [];
    end
else
    train = 1;
end

if train
    options.maxIter = 1000;
    options.minIter = 0;
    tstart = tic;
    
    model = createGPFast(data.train, options);
    fprintf('Created model: %d IPs\n', model.M_sum);
    S = load('gzdgz.mat');
    model.gz=S.gz';
    model.dgz=S.dgz';

    model = trainGPFastIter(data,model,options);
    time_train = toc(tstart);
    
    save(model_file, 'model', 'options', 'time_train');
    fprintf('Finished training: %.4f s\n', time_train);
end
end

function [model, nIter] = trainGPFastIter(data,model,options)
warning on verbose
warning('error','MATLAB:illConditionedMatrix');
warning('error','MATLAB:nearlySingularMatrix');
warning('error','MATLAB:singularMatrix');
nIter = 0;
vEM=zeros(1,options.maxIter);
[LB,UB,LBHyper,UBHyper]=optConstraintGPFast(model);
nEMPre=0;

if options.detail == 1
    mSaveTrain = zeros(options.maxIter,1);
    mSaveTest = zeros(options.maxIter,1);
    mSaveTime = zeros(options.maxIter,1);
end
for im = 1:options.maxIter
    fprintf('Iterartion M:\t%d\n',im);
    if options.detail == 1
        tstart = tic;
    end
    modelD = calPreGPFast(model, data.train);

    %% Optimize Mu and Sigma
    V = extractVarParamsGPFast(model,0);
    myObj = @(VV)varBoundVarParamsGPFast(VV,model,data.train,modelD);
    V = minConf_TMP(myObj,V,LB,UB,struct('verbose',0,'maxIter',10));
    model = returnVarParamsGPFast(model,V);
    %     [vF] = calVarBoundGPFast(model, data.train);
    %     vEM(im) = sum(vF);
    %     fprintf('\t\t Var bound E: %.4g\n',vEM(im));
    %% Optimize GP hyperparameters
    W = extractHyperParamsGPFast(model,0);
    myObj = @(VV)varBoundHyperParamsGPFast(VV,model,data.train);
    W  = minConf_TMP(myObj,W,LBHyper,UBHyper,struct('verbose',0,'maxIter',10));
    model = returnHyperParamsGPFast(model,W);
    [vF] = calVarBoundGPFast(model, data.train);
    vEM(im) = sum(vF);
    fprintf('\t\t Var bound M: %.4g\n',vEM(im));
    if isnan(vEM(im))
        nIter = inf;
        fprintf('Error: var bound is NaN\n');
        break;
    end
    if options.detail == 1
        mSaveTime(im) = toc(tstart);
        mSaveTrain(im) = sum(calLikelihoodGPFast(data.train,model), 2);
        mSaveTest(im) = sum(calLikelihoodGPFast(data.test,model), 2);
        fprintf('Target: %d\tTrain: %.4g\tTest: %.4g\tTime: %.4f\n', model.target, mSaveTrain(im), mSaveTest(im), mSaveTime(im));
    end
    if abs(vEM(im)-nEMPre)<=options.tol*abs(nEMPre)
        break
    end
    nEMPre=vEM(im);
end
end

