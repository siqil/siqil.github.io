function [LB,UB,LBHyper,UBHyper] = optConstraintGPFast(model)

nEps = 1e-8;
D=model.D;

LB=[];% Lower Bound
UB=[];% Upper Bound
M=model.M_sum;
if model.tie == 1
    n_Mu = 0;
    for u=1:model.U
        d = sum(model.Q(1:u-1)) + 1;
        n_Mu = n_Mu + model.M{d};
    end
else
    n_Mu = M;
end
LB0 = -inf(n_Mu+M*(M+1)/2,1); % Lower Bound
UB0 = inf(n_Mu+M*(M+1)/2,1);  % Upper Bound
cnt = 1;
for j = 1:M % L
    % skim global mean and m
    LB0(n_Mu+cnt)=nEps;
    cnt=cnt+(M-j+1);
end
LB=[LB;LB0];
UB=[UB;UB0];
%%
if model.tie == 1
    U = model.U;
    LBHyper = -inf(1+2*U+1,1);
    UBHyper = inf(1+2*U+1,1);
else
    LBHyper = -inf(1+2*D+1,1);
    UBHyper = inf(1+2*D+1,1);
    UBHyper(2:2:2*D) = log(1e8*model.Xm_dt(1:D))/2;
end
LBHyper(end) = (log(model.prior.gbase) + log(1e-16))/2;
UBHyper(end) = (log(model.prior.gbase) + log(1e-2))/2;
end

