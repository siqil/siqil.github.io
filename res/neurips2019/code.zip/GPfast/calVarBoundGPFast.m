function [vF] = calVarBoundGPFast(model, data)
vF = zeros(1,3);
modelD.f = 0;
modelD = calKmmKnnGPFast(model, modelD);
modelD = calKmmVarGPFast(model, modelD);
modelD = calPreMeanVarGPFast(model, data.feature{model.target}, modelD);
[vMean, vVar, vMean2DVar, mGG, mDGG, log_lambda] = calPointMeanVarGPFast(model, modelD);
vF(1) = vF(1) + sum(log_lambda);
modelD = calKmmPsiGPFast(model, data, modelD);
vF(2) = vF(2) - calIntegralValueGPFast(model, data, modelD);
if model.KL > 0
modelD.f = 0;
modelD = calDivergenceGPFast(model, modelD, 0);
vF(3) = vF(3) + modelD.f;
end
end
