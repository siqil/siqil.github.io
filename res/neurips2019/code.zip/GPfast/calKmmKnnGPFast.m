function [ modelD ] = calKmmKnnGPFast( model, modelD )
modelD.Kmm = cell(1,model.D);
modelD.Knn = zeros(1,model.D);
modelD.invKmm = cell(1,model.D);
modelD.logdetKmm = zeros(model.D,1);
modelD.noise = exp(2*model.GP.logtheta{model.D+1});
for d=1:model.D
    if ~isempty(model.Xm{d})
        modelD.Kmm{d} = ...
            feval(model.cov{:}, model.GP.logtheta{d}, model.Xm{d}, model.Xm{d});
        modelD.Kmm{d} = modelD.Kmm{d} + speye(size(modelD.Kmm{d}))*modelD.noise;
        if length(model.Xm{d}) == 1
            modelD.invKmm{d} = 1 / modelD.Kmm{d};
            modelD.logdetKmm(d) = log(abs(modelD.Kmm{d}));
        else
            modelD.invKmm{d} = inverse(modelD.Kmm{d}, 'lu');
            modelD.logdetKmm(d) = logdet(modelD.Kmm{d});
        end
    end
    modelD.Knn(d) = exp(2*model.GP.logtheta{d}(2));
end
end

