function [ Phi, Mu ] = calInfluenceGPFast( model, N, dt )

D = model.D;
Phi = zeros(D, N);

time_stamp = dt*(0:(N-1));
modelD = calKmmKnnGPFast(model);
modelD = calKmmVarGPFast(model, modelD);
for u = 0:D
    x = repmat(model.timeInf, N, D);
    if u > 0
        x(:, u) = time_stamp;
    end
    modelD = calPreMeanVarGPFast(model, x, modelD);
    [vMean, vVar] = calPointMeanVarGPFast(model, modelD);
    vF2 = vMean.^2 + vVar;
    if u > 0
        Phi(u, :) = sum(vF2, 1);
    else
        Mu = sum(vF2, 1);
    end
end
end

