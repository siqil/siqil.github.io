function [ modelD ] = calPreMeanVarGPFast( model, feat, modelD )

N = size(feat, 1);
M = model.M_sum;
modelD.Knm = zeros(N, M);
modelD.KnmInvKmm = zeros(N, M);
modelD.diagKnn = zeros(N, 1);
modelD.mask = cell(1, N);
for d=1:model.D
    x_d = feat(:, d);
    mask = isfinite(x_d);
    m_d = model.Xm_mask{d};
    modelD.mask{d} = mask;
    modelD.diagKnn(mask) = modelD.diagKnn(mask) + ...
        feval(model.cov{:}, model.GP.logtheta{d}, x_d(mask), 'diag');
    if ~isempty(model.Xm{d})
        modelD.Knm(mask, m_d) = ...
            feval(model.cov{:}, model.GP.logtheta{d}, x_d(mask), model.Xm{d});
        modelD.KnmInvKmm(mask, m_d) = modelD.Knm(mask, m_d) * modelD.invKmm{d};
    end
end
modelD.diagKnn = modelD.diagKnn + modelD.noise;
modelD.N = N;
end

