function [tdiff] = genPairTimeDiff(t1, t2, q1, q2)
% start from at least q points
j1 = q1;
j2 = q2;
% align j1, j2 to having q points
while t1(j1+1) <= t2(q2)
    j1 = j1 + 1;
end
while t2(j2+1) <= t1(q1)
    j2 = j2 + 1;
end
% initialize t_min
if t1(j1) < t2(j2)
    t_min = t2(j2);
else
    t_min = t1(j1);
end
n1 = length(t1);
n2 = length(t2);
i = 1;
while j1 < n1 && j2 < n2
    if t1(j1+1) < t2(j2+1)
        t_max = t1(j1+1);
    elseif t1(j1+1) > t2(j2+1)
        t_max = t2(j2+1);
    else
        t_max = t1(j1+1);
    end
    tdiff.min(i, 1) = t_min - t1(j1-q1+1);
    tdiff.min(i, 2) = t_min - t2(j2-q2+1);
    tdiff.max(i, 1) = t_max - t1(j1-q1+1);
    tdiff.max(i, 2) = t_max - t2(j2-q2+1);
    tdiff.diff(i) = t1(j1-q1+1) - t2(j2-q2+1);
    t_min = t_max;
    i = i + 1;
    if t1(j1+1) < t2(j2+1)
        j1 = j1 + 1;
    elseif t1(j1+1) > t2(j2+1)
        j2 = j2 + 1;
    else
        j1 = j1 + 1;
        j2 = j2 + 1;
    end
end
end