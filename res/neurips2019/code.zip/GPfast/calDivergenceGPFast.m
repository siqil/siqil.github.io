function modelD = calDivergenceGPFast(model,modelD,bflag)

InvKmmMuG = modelD.InvKmmMuG;
if model.KL == 1
InvKmmSigmaMuG = modelD.InvKmmSigmaMuG;
end
modelD.f=modelD.f+0.5*(model.M_sum-trace(InvKmmSigmaMuG));
switch bflag
    case 0
        modelD.f = modelD.f+sum(log(diag(model.var.L)))-0.5*sum(modelD.logdetKmm);
    case 1
        modelD.f = modelD.f+sum(log(diag(model.var.L)));
        modelD.var.L = modelD.var.L+(diag(1./diag(model.var.L))-modelD.InvKmmL);
        if model.KL == 1
            modelD.var.Mu = modelD.var.Mu-InvKmmMuG;
        end
    case 2
        modelD.f = modelD.f-0.5*sum(modelD.logdetKmm);
        if model.KL == 1
            modelD.prior.g0 = modelD.prior.g0 + sum(InvKmmMuG.*model.prior.g);
        end
        mtmp = (speye(model.M_sum)-InvKmmSigmaMuG);
        for d=1:model.D
            m_d = model.Xm_mask{d};
            modelD.dL_dKmm{d} = modelD.dL_dKmm{d} - 0.5*mtmp(m_d,m_d)*modelD.invKmm{d};
        end
end
end

