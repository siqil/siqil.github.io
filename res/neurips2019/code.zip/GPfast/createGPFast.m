function model = createGPFast(data, options)

%%
model.KL = options.kl;
model.tie = options.tie;
model.U = data.U;
model.Q = data.Q;
model.D = data.D;
model.timeInf = data.timeInf;
model.target = options.target;
model.const.C = 0.5772156649;
model.cov = {'covSEiso'};
%%
U = model.U;
Q = model.Q;
D = model.D;
N = [data.seqs(:).NumData];
model.prior.gbase = sum(N(model.target, :), 2) / data.T(end);
%%
model.Xm = cell(1,model.D);
model.M = cell(1,model.D);
model.M_sum = 0;
model.Xm_dt = zeros(1,model.D);
model.var.Mu = [];
if options.auto_ip > 0
    switch options.auto_ip
        case 2
            for u=1:model.U
                d1 = sum(model.Q(1:u-1)) + 1;
                timediff = data.pair_tdiff_max{d1,d1}(:,1);
                l = 0;
                r = quantile(timediff, 0.75);
                Xm_all = options.grid;
                Xm_all = Xm_all(Xm_all >= l & Xm_all <= r);
                for q = 1:model.Q(u)
                    d = sum(model.Q(1:u-1)) + q;
                    model.Xm{d} = Xm_all';
                    model.Xm_dt(d) = mean(diff(Xm_all));
                end
            end
        case 1
            for u=1:model.U
                d1 = sum(model.Q(1:u-1)) + 1;
                timediff = data.pair_tdiff_max{d1,d1}(:,1);
                l = 0;
                r = quantile(timediff, 1);
                Xm_all = options.grid;
                Xm_all = Xm_all(Xm_all >= l & Xm_all <= r);
                for q = 1:model.Q(u)
                    d = sum(model.Q(1:u-1)) + q;
                    model.Xm{d} = Xm_all';
                    model.Xm_dt(d) = mean(diff(Xm_all));
                end
            end
    end
else
    for d=1:model.D
        model.Xm{d} = options.grid';
        model.Xm_dt(d) = mean(diff(options.grid));
    end
end
%%
for u=1:model.D
    model.M{u} = length(model.Xm{u});
    model.M_sum = model.M_sum + model.M{u};
end
%%
model.Xm_mask = cell(1,model.D);
left = 1;
for u=1:model.D
    model.Xm_mask{u} = false(model.M_sum, 1);
    right = left + model.M{u} - 1;
    model.Xm_mask{u}(left:right) = true;
    left = right + 1;
end
%% prior mean
model.prior.g0 = log(model.prior.gbase) / 2;
model.prior.g = exp(model.prior.g0);
%% hyper parameters
model.GP.logtheta=cell(1,D+1);
model.var.Mu = (model.prior.gbase/2) * ones(model.M_sum, 1);
Sigma=cell(1,D);
for d=1:D
    model.GP.logtheta{d}=zeros(2, 1);
    model.GP.logtheta{d}(2) = log(model.prior.gbase)/2;
    model.GP.logtheta{d}(1) = log(model.Xm_dt(d))/2;
    model.GP.logtheta{d}(~isfinite(model.GP.logtheta{d})) = 0;
    Sigma{d} = feval(model.cov{:},model.GP.logtheta{d},model.Xm{d});
end
model.GP.logtheta{D+1} = (log(model.prior.gbase) + log(1e-3))/2; % noise
model.var.Sigma = blkdiag(Sigma{:}) + exp(2*model.GP.logtheta{D+1})*speye(model.M_sum);
model.var.L = chol(model.var.Sigma,'lower');
end
