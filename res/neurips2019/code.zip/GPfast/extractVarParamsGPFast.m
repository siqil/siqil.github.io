function [V] = extractVarParamsGPFast(model,deriv)
V = [];
if model.tie == 1
    for u=1:model.U
        d = sum(model.Q(1:u-1))+1;
        M_d = model.M{d};
        V1 = [];
        for q=1:model.Q(u)
            V1=[V1,model.var.Mu(d:d+M_d-1)];
            d = d + M_d;
        end
        if deriv
            V = [V; sum(V1, 2)];
        else
            V = [V; mean(V1, 2)];
        end
    end
    V = [V;model.var.L(tril(true(size(model.var.L))))];
else
    V=[V;model.var.Mu;model.var.L(tril(true(size(model.var.L))))];
end
end

