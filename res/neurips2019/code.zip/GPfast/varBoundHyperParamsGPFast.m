function [f,df] = varBoundHyperParamsGPFast(V,model,data)
try
model = returnHyperParamsGPFast(model,V);
modelD = calKmmKnnGPFast(model, []);
modelD = calKmmVarGPFast(model, modelD);

modelD.f=0;
modelD.prior.g0=0;
modelD.D = model.D;
modelD.Q = model.Q;
modelD.U = model.U;
modelD.M = model.M;
modelD.tie = model.tie;
modelD.GP.logtheta=cell(1,model.D+1);
modelD.dL_dKmm = cell(1, model.D);
modelD.dL_dKnm = cell(1, model.D);
modelD.dL_dMPsi = zeros(model.M_sum);
modelD.dL_dVPsi = zeros(model.M_sum, 1);
modelD.dL_dKnn = cell(1, model.D+1);
for d=1:model.D
    modelD.GP.logtheta{d}=zeros(size(model.GP.logtheta{d}));
    modelD.dL_dKmm{d} = zeros(model.M{d});
    modelD.dL_dKnn{d} = 0;
end
modelD.GP.logtheta{model.D+1}=0;
modelD.dL_dKnn{model.D+1}=0;
for d=1:model.D
    modelD.kmmDx{d} = cell(size(model.GP.logtheta{d}));
    for k=1:length(model.GP.logtheta{d})
        modelD.kmmDx{d}{k} = ...
            feval(model.cov{:}, model.GP.logtheta{d}, model.Xm{d}, [], k);
    end
end
%%
modelD = calPointValueGPFast(model, data, modelD, model.target, 2);
modelD = calIntegralGPFast(model, data, modelD,2);
if model.KL > 0
modelD = calDivergenceGPFast(model,modelD,2);
end
%%
for d=1:model.D
    for k=2
        modelD.GP.logtheta{d}(k) = modelD.GP.logtheta{d}(k) +...
            modelD.dL_dKnn{d}*2*modelD.Knn(d);
    end
    for k=1:2
        modelD.GP.logtheta{d}(k) = modelD.GP.logtheta{d}(k) + ...
            modelD.dL_dVPsi' * modelD.DvPsidx{d}{k};
        modelD.GP.logtheta{d}(k) = modelD.GP.logtheta{d}(k) + ...
            sum(sum(modelD.dL_dMPsi .* modelD.DmPsidx{d}{k}'));
    end
    if ~isempty(model.Xm{d})
        for k=1:2
            for u=model.target
                modelD.GP.logtheta{d}(k) = modelD.GP.logtheta{d}(k) + ...
                    sum(sum(modelD.dL_dKnm{d, u} .* modelD.DknmDx{d}{k}'));
            end
            modelD.GP.logtheta{d}(k) = modelD.GP.logtheta{d}(k) + ...
                sum(sum(modelD.dL_dKmm{d} .* modelD.kmmDx{d}{k}'));
        end
        modelD.GP.logtheta{model.D+1} = modelD.GP.logtheta{model.D+1} + ...
            2*modelD.noise*sum(diag(modelD.dL_dKmm{d}));
    end
end
modelD.GP.logtheta{model.D+1} = modelD.GP.logtheta{model.D+1} + ...
    modelD.dL_dKnn{model.D+1}*2*modelD.noise;
%%
f = -modelD.f;
df = -extractHyperParamsGPFast(modelD,1);
catch ME
    switch ME.identifier
        case {'MATLAB:illConditionedMatrix', 'MATLAB:nearlySingularMatrix', 'MATLAB:singularMatrix', 'alpha:too:big'}
            f = NaN;
            df = NaN;
        otherwise
            rethrow(ME)
    end
end
end


