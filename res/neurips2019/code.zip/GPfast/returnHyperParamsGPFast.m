function model = returnHyperParamsGPFast(model,V)
model.prior.g0 = V(1);
model.prior.g = exp(model.prior.g0);
nStart = 2;
N = 2;
if model.tie == 1
    for u=1:model.U
        a = sum(model.Q(1:u-1)) + 1;
        V1 = V(nStart:nStart+N-1);
        for d=a:a+model.Q(u)-1
            model.GP.logtheta{d} = V1;
        end
        nStart=nStart+N;
    end
else
    for d=1:model.D
        model.GP.logtheta{d} = V(nStart:nStart+N-1);
        nStart=nStart+N;
    end
end
% noise
model.GP.logtheta{model.D+1} = V(nStart);
end