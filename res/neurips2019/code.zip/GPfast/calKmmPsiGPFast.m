function [ modelD, dMPsi_dx, dVPsi_dx ] = calKmmPsiGPFast( model, data, modelD )

param = model.GP.logtheta;
vAlpha_sqrt = zeros(model.D, 1);
vGamma = zeros(model.D, 1);
for d=1:model.D
    vAlpha_sqrt(d) = exp(param{d}(1));
    vGamma(d) = exp(2*param{d}(2));
end
vAlpha = vAlpha_sqrt.^2;
if nargout > 1
    [mPsi, dMPsi_dx] = matrixPsiGPFast(model, data, vAlpha_sqrt, vAlpha, vGamma);
    [vPsi, dVPsi_dx] = vectorPsiGPFast(model, data, vAlpha_sqrt, vGamma);
else
    mPsi = matrixPsiGPFast(model, data, vAlpha_sqrt, vAlpha, vGamma);
    vPsi = vectorPsiGPFast(model, data, vAlpha_sqrt, vGamma);
end
modelD.invKmmMPsi = zeros(size(mPsi));
modelD.invKmmVPsi = zeros(size(vPsi));
for j=1:model.D
    m_j = model.Xm_mask{j};
    modelD.invKmmMPsi(m_j, :) = modelD.invKmm{j} * mPsi(m_j, :);
    modelD.invKmmVPsi(m_j) = modelD.invKmm{j} * vPsi(m_j);
end
modelD.vPsi = vPsi;
modelD.mPsi = mPsi;
end

