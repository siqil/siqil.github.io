function modelD = calPreGPFast(model, data)
modelD = calKmmKnnGPFast(model);
modelD = calPreMeanVarGPFast(model, data.feature{model.target}, modelD);
modelD = calKmmPsiGPFast(model, data, modelD);
end