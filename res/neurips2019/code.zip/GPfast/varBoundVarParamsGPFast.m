function [f,df] = varBoundVarParamsGPFast(V,model,data,modelD)

model = returnVarParamsGPFast(model,V);
modelD.f = 0;
modelD.D = model.D;
modelD.Q = model.Q;
modelD.U = model.U;
modelD.M = model.M;
modelD.tie = model.tie;
modelD = calKmmVarGPFast(model, modelD);
modelD.var.Mu=zeros(model.M_sum, 1);
modelD.var.L=zeros(model.M_sum);

modelD = calPointValueGPFast(model,data,modelD,model.target,1);
modelD.var.L=modelD.var.L*model.var.L;
modelD = calIntegralGPFast(model,data,modelD,1);
if model.KL > 0
modelD = calDivergenceGPFast(model,modelD,1);
end

f = -modelD.f;
df = -extractVarParamsGPFast(modelD, 1);
end
