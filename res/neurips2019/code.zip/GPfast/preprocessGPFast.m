function [ model ] = preprocessGPFast( Seqs, options )
model.U = options.U;
model.Q = ones(model.U, 1);
model.Q(options.target) = options.Q;
model.D = sum(model.Q);
model.target = options.target;
model.timeInf = inf;
DTmax = zeros(length(Seqs), model.U);
I = length(Seqs);
feature = cell(I, 1);
model.timediff = cell(1,model.U);
model.T = zeros(model.D+1, 1);
for i=1:I;
    model.seqs(i).Tstart = Seqs(i).Start;          % time start
    model.seqs(i).Tend = Seqs(i).Stop;            % time end
    model.seqs(i).NumData = zeros(model.U,1);  % number of points in each dataset
    data = splitMarkedSeq(Seqs(i).Time, Seqs(i).Mark, model.U);
    for u=1:model.U
        model.seqs(i).data{u}.time = data{u};
        model.seqs(i).NumData(u) = size(model.seqs(i).data{u}.time, 1);
        time = model.seqs(i).data{u}.time;
        if ~isempty(time) && time(end) < model.seqs(i).Tend
            time = [time; model.seqs(i).Tend];
        end
        timediff = diff(time);
        assert(all(timediff > 0));
        if ~isempty(timediff);
            DTmax(i, u) = max(timediff);
            model.timediff{u} = [model.timediff{u};timediff];
        end
        n = length(model.seqs(i).data{u}.time);
        q_b = sum(model.Q(1:u-1));
        for q=1:model.Q(u)
            if n >= q
                model.T(q_b+q) = model.T(q_b+q) + model.seqs(i).Tend - model.seqs(i).data{u}.time(q);
            end
        end
    end
    model.T(end) = model.T(end) + model.seqs(i).Tend - model.seqs(i).Tstart;
    feat = genFeat(model.seqs(i).data, model.target, ...
        model.timeInf, model.U, model.Q);
    for u=model.target
        feature{i, u} = feat{u};
    end
end
model.feature = cell(1, model.U);
for u=model.target
    model.feature{u} = vertcat(feature{:, u});
end
model.DTmax = max(DTmax, [], 1);

model.pair_tdiff_diff = cell(model.D,model.D);
model.pair_tdiff_min = cell(model.D,model.D);
model.pair_tdiff_max = cell(model.D,model.D);
for i=1:I
    Tend = model.seqs(i).Tend;
    for j=1:model.U
        for qj=1:model.Q(j)
            for k=j:model.U
                if k==j
                    qk_beg = qj;
                else
                    qk_beg = 1;
                end
                for qk=qk_beg:model.Q(k)
                    a = sum(model.Q(1:(j-1))) + qj;
                    b = sum(model.Q(1:(k-1))) + qk;
                    tj = model.seqs(i).data{j}.time;
                    tk = model.seqs(i).data{k}.time;
                    if checkSeq(tj, qj, Tend) && checkSeq(tk, qk, Tend)
                        pair_tdiff = genPairTimeDiff([tj; Tend], [tk; Tend], qj, qk);
                        model.pair_tdiff_diff{a,b} = [model.pair_tdiff_diff{a,b}; pair_tdiff.diff'];
                        model.pair_tdiff_min{a,b} = [model.pair_tdiff_min{a,b}; pair_tdiff.min];
                        model.pair_tdiff_max{a,b} = [model.pair_tdiff_max{a,b}; pair_tdiff.max];
                    end
                end
            end
        end
    end
end
end

function [valid] = checkSeq(t, q, Tend)
if length(t) >= q && t(q) < Tend
    valid = true;
else
    valid = false;
end
end


