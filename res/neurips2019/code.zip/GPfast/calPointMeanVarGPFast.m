function [vMean, vVar, vMean2DVar, mGG, mDGG, log_lambda] = ...
    calPointMeanVarGPFast(model, modelD)
N = length(modelD.diagKnn);
vMean = repmat(model.prior.g, 1, N);
vVar = modelD.diagKnn';
vMean = vMean + (modelD.Knm*modelD.InvKmmMuG)';
vVar = vVar + (sum(modelD.KnmInvKmm.*(modelD.Knm*(modelD.InvKmmSigma-speye(model.M_sum))),2))';
if nargout >= 3
    vMean2DVar = vMean.^2/2./vVar;
end
if nargout >= 4
    if nargout >= 5
        [mGG, mDGG] = queryGz(vMean2DVar, model.gz, model.dgz);
    else
        mGG = queryGz(vMean2DVar, model.gz, model.dgz);
    end
    if nargout >= 6
        log_lambda = log(0.5) - model.const.C - mGG + log(vVar);
    end
end
