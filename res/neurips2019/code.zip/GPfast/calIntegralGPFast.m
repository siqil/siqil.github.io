function modelD = calIntegralGPFast(model, data, modelD, bflag)

switch bflag
    case 2
        [modelD, dPsi_dx, dVPsi_dx] = calKmmPsiGPFast(model, data, modelD);
        modelD.DmPsidx = dPsi_dx;
        modelD.DvPsidx = dVPsi_dx;
end

[nfInt, modelD.VPsiInvKmmMuG] = calIntegralValueGPFast(model, data, modelD);

switch bflag
    case 1
        modelD.f=modelD.f-nfInt;
        invKmmMPsi = modelD.invKmmMPsi;
        invKmmVPsi = modelD.invKmmVPsi;
        modelD.var.Mu= modelD.var.Mu - ...
            2*invKmmMPsi*modelD.InvKmmMuG - ...
            2*invKmmVPsi*model.prior.g;
        modelD.var.L = modelD.var.L-2*invKmmMPsi*modelD.InvKmmL;
    case 2
        modelD.f=modelD.f-nfInt;
        invKmmMPsi = modelD.invKmmMPsi;
        invKmmVPsi = modelD.invKmmVPsi;
        InvKmmSigmaMuG = modelD.InvKmmSigmaMuG;
        mtmp_a = (speye(model.M_sum)-InvKmmSigmaMuG);
        mtmp_b = (2*invKmmMPsi*InvKmmSigmaMuG-invKmmMPsi);
        for d=1:model.D
            m_d = model.Xm_mask{d};
            mtmp_a(:,m_d) = mtmp_a(:,m_d) * modelD.invKmm{d};
            mtmp_b(:,m_d) = mtmp_b(:,m_d) * modelD.invKmm{d};
        end
        mtmp_b =  mtmp_b + ...
            2*model.prior.g*modelD.InvKmmMuG*invKmmVPsi';
        for d=1:model.D
            m_d = model.Xm_mask{d};
            modelD.dL_dKmm{d} = modelD.dL_dKmm{d} + mtmp_b(m_d,m_d);
            modelD.dL_dKnn{d} = modelD.dL_dKnn{d} - data.T(d);
        end
        modelD.dL_dMPsi = modelD.dL_dMPsi + mtmp_a;
        modelD.dL_dVPsi = modelD.dL_dVPsi - ...
            2*model.prior.g*modelD.InvKmmMuG;
        modelD.prior.g0 = modelD.prior.g0 - 2*(...
            model.prior.g*modelD.VPsiInvKmmMuG - ...
            model.prior.g*sum(invKmmVPsi)*model.prior.g -...
            sum(model.prior.g*invKmmMPsi*modelD.InvKmmMuG, 1));
        modelD.prior.g0 = modelD.prior.g0 - 2*(...
            model.prior.g^2*data.T(end));
        modelD.dL_dKnn{model.D+1} = modelD.dL_dKnn{model.D+1} - ...
            data.T(model.D+1);
end
end